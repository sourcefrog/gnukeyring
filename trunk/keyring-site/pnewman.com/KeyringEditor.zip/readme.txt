-----------------------------------------------------------------------

	KeyringEditor v1.1

-----------------------------------------------------------------------


KeyringEditor is based on:
Java Keyring v0.6
Copyright 2004 Frank Taylor <keyring@lieder.me.uk>

KeyringEditor is a Java-based frontend for "Keyring for Palm OS".
It can be used to read and write backup copies of the Keys-Gtkr.pdb
found after synchronising your Palm to your desktop. 

Be aware: 
this program is not HOTSYNC compatible. You have to overwrite
the "Keys-Gtkr.pdb" file on Palm after editing with KeyringEditor. For
example use filez (http://www.nosleep.net) to delete the database on 
Palm or make sure to overwrite and not to synchronize the database.

It works with Keyring database format 4 (v1.2.3) and 5 (v2.0-pre4).

REQUIREMENTS ----------------------------------------------------------
	
	You need to have Java installed on your System, see 
	http://java.sun.com/downloads/index.html
	
	For AES with 256 bit keys you need to install the
	Unlimited Strength Java Cryptography Extension Policy Files:


INSTALLATION ----------------------------------------------------------

	Unzip the ZIP file and place the files somewhere on your system
	and run the	following command:

   	java -jar KeyringEditor.jar [Keys-Gtkr.pdb]

	Make a backup of your Keys-Gtkr.pdb before usage!


FEATURES --------------------------------------------------------------

	* Add, edit and delete entries
	* Edit category-names
	* Lock application
	* Set application timeout (keyringeditor.ini)
	* Convert database between Keyring database format 4 and 5
	  with different settings for cipher type and iterations
	* Support of a separator in the entry title (keyringeditor.ini) to
	  get different levels in the tree view
	* Save entries to a CSV file
	* Generate new minimal database in Keyring database format 4 
        (password "test")
	* /examples contains example databases with different cipher types 
        (password "test")


LICENSE ---------------------------------------------------------------

	These programs are distributed in the hope that they will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

	GPL (see info/gpl.txt)


LINKS -----------------------------------------------------------------

	FileZ - http://www.nosleep.net/
	Keyring - http://gnukeyring.sourceforge.net/
	Java Keyring - http://www.lieder.dsl.pipex.com/software/JavaKeyring/


HOMEPAGE --------------------------------------------------------------

	www.ict.tuwien.ac.at/keyring


CONTACT ---------------------------------------------------------------

	markus.griessnig AT gmx.at
	treytl AT ict.tuwien.ac.at


COPYRIGHT -------------------------------------------------------------

	Copyright 2004 Markus Griessnig
	Vienna University of Technology
	Institute of Computer Technology

-----------------------------------------------------------------------