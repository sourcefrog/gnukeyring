/*
Keyring for Android

Copyright (C) 2011 Peter Newman <pn@pnewman.com>

Keyring for Android is based on:
KeyringEditor
Copyright 2004 Markus Griessnig
Vienna University of Technology Institute of Computer Technology

KeyringEditor is based on:
Java Keyring v0.6
Copyright 2004 Frank Taylor <keyring@lieder.me.uk>

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details:
<http://www.gnu.org/licenses/>.
*/

package com.pnewman.keyring;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class FileDialog extends ListActivity {
    private static final String root = "/";

	private List<String> item = null;
	private List<String> path = null;
	private TextView myPath;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        setContentView(R.layout.file_dialog);
        setTitle(R.string.file_dialog_title);
        myPath = (TextView) findViewById(R.id.path);
    	File extDir = Environment.getExternalStorageDirectory();
        getDir(extDir.getAbsolutePath());
	}

    private void getDir(String dirPath) {
        myPath.setText("Path: " + dirPath);
        
        item = new ArrayList<String>();
        path = new ArrayList<String>();
        
        File f = new File(dirPath);
        File[] files = f.listFiles(new FileFilter() {
			@Override
			public boolean accept(File pathname) {
				//If a file or directory is hidden, or unreadable, don't show it in the list.
				if (pathname.isHidden())
					return false;
				if (!pathname.canRead())
					return false;

				return true;
			}
		});

        if (!dirPath.equals(root)) {
			item.add("../");
			path.add(f.getParent());
        }
        
        File file;
        for (int i=0; i < files.length; i++) {
	        file = files[i];
	        path.add(file.getPath());
	        if (file.isDirectory())
	           item.add(file.getName() + "/");
	        else
	           item.add(file.getName());
        }

        //Sort the files alphabetically.
        Collections.sort(item);
        Collections.sort(path);
        
        ArrayAdapter<String> fileList =
        	new ArrayAdapter<String>(this, R.layout.row, item);
        setListAdapter(fileList);
    }

    
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
     
    	File file = new File(path.get(position));
     
    	if (file.isDirectory()) {
    		if(file.canRead()) {
    			getDir(path.get(position));
    		} else {
    			new AlertDialog.Builder(this)
    				.setIcon(R.drawable.icon)
    				.setTitle("Can't read folder: " + file.getName())
    				.setPositiveButton("OK", 
    					new DialogInterface.OnClickListener() {
          
							@Override
							public void onClick(DialogInterface dialog, int which) {

							}
    					}).show();
    		}
    	} else {
	    	Intent mIntent = new Intent();
	    	mIntent.putExtra(Keyring.KEY_FILE_NAME, file.getAbsolutePath());
	    	setResult(RESULT_OK, mIntent);
	    	finish();
    	}
    }
}
