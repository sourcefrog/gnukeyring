/*
Keyring for Android

Copyright (C) 2011 Peter Newman <pn@pnewman.com>

Keyring for Android is based on:
KeyringEditor
Copyright 2004 Markus Griessnig
Vienna University of Technology Institute of Computer Technology

KeyringEditor is based on:
Java Keyring v0.6
Copyright 2004 Frank Taylor <keyring@lieder.me.uk>

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details:
<http://www.gnu.org/licenses/>.
*/

package com.pnewman.keyring;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;


public class EditEntry extends Activity {

	private EditText mEditTitle;
	private EditText mEditAccount;
	private EditText mEditPasswd;
	private EditText mEditNotes;
	private boolean mCardModified;
	private int mEntryId;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.edit_entry);
		mEditTitle = (EditText) findViewById(R.id.edit_title);
		mEditAccount = (EditText) findViewById(R.id.edit_account);
		mEditPasswd = (EditText) findViewById(R.id.edit_passwd);
		mEditNotes = (EditText) findViewById(R.id.edit_notes);
    	mCardModified = false;
        Intent caller = getIntent();
        String pageTitle = caller.getStringExtra(Keyring.KEY_DISPLAY_PAGE_TITLE);
        setTitle(pageTitle);
        float textSize = caller.getFloatExtra(Keyring.KEY_ENTRY_TEXT_SIZE,
        		(float) Preferences.DEFAULT_TEXT_SIZE);
        mEditTitle.setTextSize(textSize);
        mEditAccount.setTextSize(textSize);
        mEditPasswd.setTextSize(textSize);
        mEditNotes.setTextSize(textSize);
        mEntryId = caller.getIntExtra(Keyring.KEY_ENTRY_ID, -1);
        mEditTitle.setText(caller.getStringExtra(Keyring.KEY_ENTRY_TITLE_TEXT));
        mEditAccount.setText(caller.getStringExtra(Keyring.KEY_ENTRY_ACCOUNT_TEXT));
        mEditPasswd.setText(caller.getStringExtra(Keyring.KEY_ENTRY_PASSWD_TEXT));
        mEditNotes.setText(caller.getStringExtra(Keyring.KEY_ENTRY_NOTES_TEXT));

        //add text watchers
        mEditTitle.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) { }
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { } 
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            	mCardModified = true;
            } 
        }); 
        mEditAccount.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) { }
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { } 
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            	mCardModified = true;
            } 
        });
        mEditPasswd.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) { }
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { } 
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            	mCardModified = true;
            } 
        });
        mEditNotes.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) { }
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { } 
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            	mCardModified = true;
            } 
        });
	}

	
	//action for save card button
	public void saveCard(View view) {
    	Intent mIntent = new Intent();
    	mIntent.putExtra(Keyring.KEY_ENTRY_ID, mEntryId);
    	mIntent.putExtra(Keyring.KEY_ENTRY_TITLE_TEXT, mEditTitle.getText().toString());
    	mIntent.putExtra(Keyring.KEY_ENTRY_ACCOUNT_TEXT, mEditAccount.getText().toString());
    	mIntent.putExtra(Keyring.KEY_ENTRY_PASSWD_TEXT, mEditPasswd.getText().toString());
    	mIntent.putExtra(Keyring.KEY_ENTRY_NOTES_TEXT, mEditNotes.getText().toString());
    	if (mCardModified) setResult(RESULT_OK, mIntent);
    	else setResult(RESULT_CANCELED, mIntent);
    	finish();
	}

	
	//action for cancel button
	public void cancel(View view) {
    	Intent mIntent = new Intent();
    	setResult(RESULT_CANCELED, mIntent);
    	finish();
	}
}
