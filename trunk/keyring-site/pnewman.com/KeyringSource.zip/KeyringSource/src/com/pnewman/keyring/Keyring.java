/*
Keyring for Android

Copyright (C) 2011 Peter Newman <pn@pnewman.com>

Keyring for Android is based on:
KeyringEditor
Copyright 2004 Markus Griessnig
Vienna University of Technology Institute of Computer Technology

KeyringEditor is based on:
Java Keyring v0.6
Copyright 2004 Frank Taylor <keyring@lieder.me.uk>

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details:
<http://www.gnu.org/licenses/>.
*/

package com.pnewman.keyring;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.method.ScrollingMovementMethod;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class Keyring extends Activity {

	private static final int DIALOG_PASSWD_ID = 0;
    private static final int ACTIVITY_GET_FILENAME = 2;
    private static final int ACTIVITY_DISPLAY_LIST = 3;
    private static final int ACTIVITY_SET_PREFERENCES = 4;
    private static final int ACTIVITY_NEW_ENTRY = 5;
    private static final int ACTIVITY_EDIT_ENTRY = 6;
    private static final int MENU_NEW_ENTRY_ID = 0;
    private static final int MENU_EDIT_ENTRY_ID = 1;
    private static final int MENU_DELETE_ENTRY_ID = 2;
    private static final int MENU_OPEN_FILE_ID = 3;
    private static final int MENU_PREFERENCES_ID = 4;
    private static final int MENU_ABOUT_ID = 5;
    private static final int MENU_HELP_ID = 6;
    private static final int STATE_INIT = 0;
    private static final int STATE_IDLE = 1;
    private static final int STATE_FILE_LOADED = 2;
    private static final int STATE_READY = 3;
    private static final int STATE_LOCKED = 4;
    public static final String KEY_FILE_NAME = "fileName";
	public static final String KEY_DISPLAY_LIST = "displayList";
    public static final String KEY_DISPLAY_PAGE_TITLE = "displayPageTitle";
    public static final String KEY_DISPLAY_HELP_FILE = "displayHelpFile";
    public static final String KEY_ENTRY_ID = "entryId";
    public static final String KEY_ENTRY_TITLE_TEXT = "entryTitleText";
    public static final String KEY_ENTRY_ACCOUNT_TEXT = "entryAccountText";
    public static final String KEY_ENTRY_PASSWD_TEXT = "entryPasswdText";
    public static final String KEY_ENTRY_NOTES_TEXT = "entryNotesText";
    public static final String KEY_ENTRY_TEXT_SIZE = "entryTextSize";
    public static final String KEY_LIST_SELECTION = "listSelection";
    public static final String KEY_SETTINGS_FILENAME = "filename";
    public static final String KEY_SETTINGS_FONT = "textFont";
    public static final String KEY_SETTINGS_STYLE = "textStyle";
    public static final String KEY_SETTINGS_SIZE = "textSize";
    public static final String KEY_SETTINGS_TIMEOUT = "timeoutValue";
    public static final String KEY_SETTINGS_READ_ONLY_MODE = "readOnlyMode";

    private static final int TIMEOUT_30_SECS = 30000;
    private static final int TIMEOUT_1_MIN = 60000;
    private static final int TIMEOUT_5_MISN = 300000;
    private static final int TIMEOUT_10_MINS = 600000;
    private static final int TIMEOUT_15_MINS = 900000;

	/**
	 * Current loaded keyring database
	 */
	private String mFilename;

	private TextView mBodyText;
	private Handler mHandler;			//one-shot timer
	private Runnable mTimeoutCallback;	//timer callback
	private Button mLockButton;
	private Model model;
	private int mCurrentEntry;
	private ArrayList<String> mTitleList;
	private ArrayList<Integer> mTitleIdList;
	private int mState;
	private long mStartLastTimeout;
	private int mtimeoutValue = TIMEOUT_30_SECS;
	private boolean mReadOnly;

	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mBodyText = (TextView) findViewById(R.id.body);
    	mBodyText.setMovementMethod(new ScrollingMovementMethod());
    	mBodyText.setClickable(false);		//to avoid dimming on scroll
    	mBodyText.setLongClickable(false);	//to avoid dimming on scroll
    	mLockButton = (Button) findViewById(R.id.button_lock);
    	mTitleList = new ArrayList<String>();
    	mTitleIdList = new ArrayList<Integer>();
    	mHandler = new Handler();
    	mFilename = null;
    	model = null;
    	mCurrentEntry = -1;
    	mStartLastTimeout = 0;
    	mState = STATE_INIT;
    	mReadOnly = true;
    	
    	//hides soft keyboard on startup
    	getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

    	//add a context menu to text view
    	registerForContextMenu(mBodyText);
    	
    	try {
			//restore text display attributes
	        restorePreferences();

	        //check whether intent specifies the file
			String filePath = null;
			Uri uri = getIntent().getData();
			if (uri != null) filePath = uri.getEncodedPath();

			if (filePath == null) {
				//intent does not specify file so restore previous file
				SharedPreferences settings = getPreferences(0);
				filePath = settings.getString(KEY_SETTINGS_FILENAME, null);
			}

			if (filePath != null && (mFilename == null || mFilename.compareTo(filePath) != 0)) {
				loadDatabase(filePath);
			}
    	}
    	catch (ClassCastException e) {
    		//ignore exceptions
    	}

    	//restore previous state, if any
    	//typically occurs if device rotated portrait to landscape or back
    	if (savedInstanceState != null) {
    		mCurrentEntry = savedInstanceState.getInt(KEY_ENTRY_ID);
    	}

    	//set callback for timer
    	mTimeoutCallback = new Runnable() {
    		public void run() {
    			//lock database on timeout
    			lockDatabase(null);
    		}
    	};

    	if (mState == STATE_INIT) gotoStateIdle();
	}


	//save state, typically occurs if device rotated portrait to landscape or back
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_ENTRY_ID, mCurrentEntry);
    }
    
    
    @Override
    protected void onResume() {
        super.onResume();
		if (System.currentTimeMillis() - mStartLastTimeout > mtimeoutValue &&
				mState == STATE_READY) {
			//timeout has expired, lock database
			lockDatabase(null);
		}
    }
    
    
    //set menu items accessed from the menu button
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        boolean result = super.onCreateOptionsMenu(menu);
        menu.clear();
        menu.add(0, MENU_OPEN_FILE_ID, 0, R.string.menu_open_file);
        menu.add(0, MENU_PREFERENCES_ID, 0, R.string.menu_settings);
        menu.add(0, MENU_ABOUT_ID, 0, R.string.menu_about);
        menu.add(0, MENU_HELP_ID, 0, R.string.menu_help);
        return result;
    }
    

    //respond to menu items selected from the menu button
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case MENU_OPEN_FILE_ID:
        	openFileDialog();
        	return true;
        case MENU_PREFERENCES_ID:
        	startActivityForResult(new Intent(this, Preferences.class), ACTIVITY_SET_PREFERENCES);
        	return true;
        case MENU_ABOUT_ID:
        	displayAbout();
        	return true;
        case MENU_HELP_ID:
        	loadHelpFile();
        	return true;
        }
    	return super.onOptionsItemSelected(item);
    }
    

    //set menu items accessed from the context menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if (!mReadOnly) {
	        menu.add(0, MENU_NEW_ENTRY_ID, 0, R.string.menu_new_entry);
	        menu.add(0, MENU_EDIT_ENTRY_ID, 0, R.string.menu_edit_entry);
	        menu.add(0, MENU_DELETE_ENTRY_ID, 0, R.string.menu_delete_entry);
        }
    }
    
    
    public boolean onContextItemSelected(MenuItem item) {
        switch(item.getItemId()) {
        case MENU_NEW_ENTRY_ID:
        	newEntry();
        	return true;
        case MENU_EDIT_ENTRY_ID:
        	editEntry();
        	return true;
        case MENU_DELETE_ENTRY_ID:
        	deleteEntryDialog();
        	return true;
        }
        return super.onContextItemSelected(item);
    }
    
    
	private void restorePreferences() {
		SharedPreferences settings = getPreferences(0);
	    int fontSetting = settings.getInt(KEY_SETTINGS_FONT, 0);
	    if (fontSetting < 0 || fontSetting >= Preferences.NUM_FONTS) fontSetting = 0;	    
	    Typeface tf = Typeface.DEFAULT;
        switch (fontSetting) {
        	case 0: tf = Typeface.DEFAULT;
        		break;
        	case 1: tf = Typeface.MONOSPACE;
        		break;
        	case 2: tf = Typeface.SANS_SERIF;
        		break;
        	case 3: tf = Typeface.SERIF;
        		break; 	
        }
	    int styleSetting = settings.getInt(KEY_SETTINGS_STYLE, 0);
	    if (styleSetting < 0 || styleSetting >= Preferences.NUM_STYLES) styleSetting = 0;
        mBodyText.setTypeface(tf, styleSetting);

	    int sizeSetting = settings.getInt(KEY_SETTINGS_SIZE, Preferences.DEFAULT_TEXT_SIZE);
	    if (sizeSetting < Preferences.SIZE_START_VALUE ||
	    	sizeSetting > Preferences.SIZE_ARRAY_MAX * 2 + Preferences.SIZE_START_VALUE)
	    	sizeSetting = Preferences.DEFAULT_TEXT_SIZE;
        mBodyText.setTextSize((float) sizeSetting);

        int oldTimeoutValue = mtimeoutValue;
        int timeoutSetting = settings.getInt(KEY_SETTINGS_TIMEOUT, 0);
	    if (timeoutSetting < 0 || timeoutSetting >= Preferences.NUM_TIMEOUT_VALUES) timeoutSetting = 0;
        switch (timeoutSetting) {
        	case 0: mtimeoutValue = TIMEOUT_30_SECS;
        		break;
        	case 1: mtimeoutValue = TIMEOUT_1_MIN;
        		break;
        	case 2: mtimeoutValue = TIMEOUT_5_MISN;
        		break;
        	case 3: mtimeoutValue = TIMEOUT_10_MINS;
        		break; 	
        	case 4: mtimeoutValue = TIMEOUT_15_MINS;
        		break; 	
        }     
		if (mState == STATE_READY && oldTimeoutValue != mtimeoutValue) {
			//timeout value has changed
			resetTimeout();
		}

        mReadOnly =
            settings.getBoolean(KEY_SETTINGS_READ_ONLY_MODE, Preferences.DEFAULT_READ_ONLY_MODE);
	}
	
	
	@Override
	//build password dialog
	protected Dialog onCreateDialog(int id) {
		AlertDialog dialog = null;
		switch(id) {
		case DIALOG_PASSWD_ID:
		       LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		       
		       final View layout = inflater.inflate(R.layout.passwd_dialog, (ViewGroup) findViewById(R.id.root));
		       final EditText editPasswd = (EditText) layout.findViewById(R.id.EditText_Passwd);

		       AlertDialog.Builder builder = new AlertDialog.Builder(this);
		       builder.setTitle(R.string.passwd_dialog_title);
		       builder.setView(layout);

		    	//listen for enter key press in the edit window
		       editPasswd.setOnKeyListener(new OnKeyListener() {
		    	    public boolean onKey(View v, int keyCode, KeyEvent event) {
		    	        if (event.getAction() == KeyEvent.ACTION_DOWN) {
			    	        if (keyCode == KeyEvent.KEYCODE_ENTER) {
			    	        	checkPassword(editPasswd.getText());
			    	        	editPasswd.setText("");
					    	    removeDialog(DIALOG_PASSWD_ID);
			    	        	return true;
		    	        	}
		    	        }
		    	        return false;
		    	    }
		    	});

		    	builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
		    	   public void onClick(DialogInterface dialog, int whichButton) {
	    	        	editPasswd.setText("");
						removeDialog(DIALOG_PASSWD_ID);
						if (mState != STATE_LOCKED) {
							gotoStateIdle();
						}
		    	   }
		    	});
		    	 
		    	builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
		    	   public void onClick(DialogInterface dialog, int which) {
		    		   	checkPassword(editPasswd.getText());
	    	        	editPasswd.setText("");
		    		   	removeDialog(DIALOG_PASSWD_ID);
		    	   }
		    	});
		       
		    	dialog = builder.create();
		    	break;
		}
		return dialog;
	}
	
	
	private void loadDatabase(String dbFilename) {

		if(dbFilename != null) {
	    	if (dbFilename.length() == 0) return;

	    	String state = Environment.getExternalStorageState();
	    	if (!Environment.MEDIA_MOUNTED.equals(state) &&
	    		!Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
	    			alertMsg("Media is unavailable");
	        		return;
	    	}
			
			model = new Model();

			try {
				model.loadData(dbFilename);
				saveFilename(dbFilename);
			}
			catch(Exception ex) {
				msgError(ex, "Failed to open database file", false);
				gotoStateIdle();
				return;
			}

	    	if (mState == STATE_INIT) {
	    		openedFileStatusMsg(dbFilename);
	    	}

	    	mState = STATE_FILE_LOADED;

			// Password dialog
	    	showDialog(DIALOG_PASSWD_ID);
	    	mBodyText.setText("");
		}
	}
	

	private void gotoStateIdle() {
		model = null;
		mFilename = null;
    	mState = STATE_IDLE;
		mBodyText.setText("No database file loaded\n\nUse Menu/Open File");
	}

	
	private void saveFilename(String dbFilename) {
		mFilename = dbFilename;

		SharedPreferences settings = getPreferences(0);
		String str = settings.getString(KEY_SETTINGS_FILENAME, null);
		if (str != null && dbFilename.compareTo(str) == 0) return;

		SharedPreferences.Editor editor = settings.edit();
		editor.putString(KEY_SETTINGS_FILENAME, dbFilename);
		editor.commit();
	}
	

	private void openedFileStatusMsg(String dbFilename) {
		Toast.makeText(Keyring.this, "Opened file: " + extractFileName(dbFilename),
    		    Toast.LENGTH_LONG).show();
	}
	

	//remove storage dir path from filename
	private String extractFileName(String filename) {
    	File extDir = Environment.getExternalStorageDirectory();
        String dirname = extDir.getAbsolutePath();
        int index = filename.indexOf(dirname);
        if (index > -1 && dirname.length() > 0) {
        	filename = filename.substring(index + dirname.length() + 1);
        }
        return filename;
	}
	
	
	// password -------------------------------------------------------
	/**
	 * Show password dialog and set Keyring database password.
	 *
	 * @return False if dialog cancelled (Boolean)
	 */
	private void checkPassword(CharSequence password) {
		
    	char[] passwd = new char[password.length()];
    	for(int i=0; i < password.length(); i++) {
    		passwd[i] = password.charAt(i);
		}

		try {
			model.crypto.setPassword(passwd);
        }
		catch(Exception ex) {
			badPasswdMsg("checkPassword: " + ex.getMessage());
			return;
		}

    	//set lock timer
		resetTimeout(); 
		mLockButton.setText("Lock");

    	if (mState == STATE_LOCKED) {
        	mState = STATE_READY;
        	listAllEntries(null);
        } else {
        	sortEntries(-1);
        	mState = STATE_READY;
        	if (mCurrentEntry == -1) {
    			listAllEntries(null);
    		} else {
    			showEntry(mCurrentEntry);
    		}
        }
	}
	

    private void badPasswdMsg(String msg) {
    	new AlertDialog.Builder(this)
//    		.setIcon(R.drawable.icon)
    		.setMessage(msg)
    		.setPositiveButton("OK", 
    			new DialogInterface.OnClickListener() {
    				@Override
    				public void onClick(DialogInterface dialog, int which) {
    					//password failed, try again
    					showDialog(DIALOG_PASSWD_ID);
    				}
    			}).show();
    }
    

	private int sortEntries(int matchId) {
		//sort entries according to title
		Collections.sort(model.getEntries());

		//build list of titles
		mTitleList.clear();
		mTitleIdList.clear();		
    	Entry entry;
    	int returnId = -1;
    	int cnt = 0;
    	for(Enumeration e = model.getElements(); e.hasMoreElements(); ) {
			entry = (Entry) e.nextElement();
	        // add a reference to the list
			mTitleList.add(entry.getTitle());
	        mTitleIdList.add(entry.getEntryId());
	        if (entry.getEntryId() == matchId) returnId = cnt;
	        ++cnt;
		}

    	if (mTitleIdList.size() == 0) {
    		alertMsg("Database contains no entries");
    		gotoStateIdle();
    		return -1;
    	}
		return returnId;
	}
	
	
	private void showEntry(int id) {
		if (mState != STATE_READY) {
			return;
		}
		
        mCurrentEntry = id;
        Entry card = (Entry) model.getEntries().get(id);
//    	mBodyText.setText(Html.fromHtml("<b>Title:</b> " + card.getTitle() +
//    			"<br /><b>Account:</b> " + card.getAccount() +
//    			"<br /><b>Passwd:</b> " + card.getPassword()) +
//    			"\n\n" + card.getNotes());
    	mBodyText.setText("Title: " + card.getTitle() +
    			"\nAccount: " + card.getAccount() +
    			"\nPasswd: " + card.getPassword() +
    			"\n\n" + card.getNotes());
    	
    	//restart lock timer
		resetTimeout(); 
	}
	

	//set lock timer
	private void resetTimeout() {
	    mHandler.removeCallbacks(mTimeoutCallback);
	    mHandler.postDelayed(mTimeoutCallback, mtimeoutValue);
    	mStartLastTimeout = System.currentTimeMillis();
	}
    

	private void newEntry() {
		if (mReadOnly) {
			readOnlyAlert();
			return;
		}
		if (mState != STATE_READY) {
			return;
		}
		float textSize = mBodyText.getTextSize();
		Intent i = new Intent(this, EditEntry.class);
        i.putExtra(KEY_ENTRY_ID, -1);
        i.putExtra(KEY_ENTRY_TITLE_TEXT, "");
        i.putExtra(KEY_ENTRY_ACCOUNT_TEXT, "");
        i.putExtra(KEY_ENTRY_PASSWD_TEXT, "");
        i.putExtra(KEY_ENTRY_NOTES_TEXT, "");
        i.putExtra(KEY_ENTRY_TEXT_SIZE, textSize);
        i.putExtra(KEY_DISPLAY_PAGE_TITLE, getString(R.string.new_entry_page_title));
        startActivityForResult(i, ACTIVITY_NEW_ENTRY);
	}
	
	
	private void editEntry() {

		if (mReadOnly) {
			readOnlyAlert();
			return;
		}
		if (mState != STATE_READY) {
			return;
		}
		if (mCurrentEntry < 0 || mCurrentEntry >= model.getEntriesSize()) return;

        Entry entry = (Entry) model.getEntries().get(mCurrentEntry);

		float textSize = mBodyText.getTextSize();
		Intent i = new Intent(this, EditEntry.class);
        i.putExtra(KEY_ENTRY_ID, mCurrentEntry);
        i.putExtra(KEY_ENTRY_TITLE_TEXT, entry.getTitle());
        i.putExtra(KEY_ENTRY_ACCOUNT_TEXT, entry.getAccount());
        i.putExtra(KEY_ENTRY_PASSWD_TEXT, entry.getPassword());
        i.putExtra(KEY_ENTRY_NOTES_TEXT, entry.getNotes());
        i.putExtra(KEY_ENTRY_TEXT_SIZE, textSize);
        i.putExtra(KEY_DISPLAY_PAGE_TITLE, getString(R.string.new_entry_page_title));
        startActivityForResult(i, ACTIVITY_EDIT_ENTRY);
	}
	
	
	private void deleteEntryDialog() {
		if (mReadOnly) {
			readOnlyAlert();
			return;
		}
		if (mState != STATE_READY) {
			return;
		}
		if (model.getEntriesSize() < 2) {
			alertMsg("Cannot delete the last entry. Database with no entries is invalid. " +
					"Add a new entry then use delete.");
			return;
		}
		if (mCurrentEntry < 0 || mCurrentEntry >= model.getEntriesSize()) {
			alertMsg("deleteEntryDialog: bad current entry id");
			return;
		}
		new AlertDialog.Builder(this)
//		.setIcon(R.drawable.icon)
		.setMessage("Are you sure you want to delete this entry?")
		.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					//yes, delete the card
					deleteEntry(mCurrentEntry);
				}
			})
		.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) { }
				})
		.show();
	}
	
	
	private void readOnlyAlert() {
		alertMsg("Keyring is in Read Only Mode. See Menu/Preferences to enable Read/Write Mode.");
	}
	

	private void deleteEntry(int entryId) {
        Entry currentEntry = (Entry) model.getEntries().get(entryId);
        if (currentEntry.entryId != mTitleIdList.get(entryId)) {
        	alertMsg("Delete entry: bad entry id");
        	return;
        }
        
        model.removeEntry((Object) currentEntry);
		mCurrentEntry = -1;
		sortEntries(-1);

		// save changes
		try {
			model.saveData(mFilename);
		}
		catch(Exception ex) {
			msgError(ex, "deleteEntry: ", false);
		}

		listAllEntries(null);
	}
	

	//list button: list first lines of all entries
    public void listAllEntries(View view) {   	
    	if (mState == STATE_LOCKED) {
    		showDialog(DIALOG_PASSWD_ID);
    	}   	
    	else if (mState == STATE_READY) {
	    	Intent i = new Intent(this, SearchList.class);
	        i.putStringArrayListExtra(KEY_DISPLAY_LIST, mTitleList);
	        i.putExtra(KEY_DISPLAY_PAGE_TITLE, getString(R.string.list_entries));
	        startActivityForResult(i, ACTIVITY_DISPLAY_LIST);
    	}
    	else if (mState == STATE_IDLE) {
    		gotoStateIdle();
    	}
    }
    
    
    //lock button: lock database so further use requires password
    public void lockDatabase(View view) {
    	if (mState == STATE_READY) {
        	mState = STATE_LOCKED;
    		mBodyText.setText("Database Locked");
    		mLockButton.setText("Unlock");
    	}
    	else if (mState == STATE_LOCKED) {
    		showDialog(DIALOG_PASSWD_ID);
    	}
    	else if (mState == STATE_IDLE) {
    		gotoStateIdle();
    	}
        mHandler.removeCallbacks(mTimeoutCallback);
    }
    

    //initiate open file activity
    private void openFileDialog() {
    	String state = Environment.getExternalStorageState();
    	if (!Environment.MEDIA_MOUNTED.equals(state) &&
    		!Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
    			alertMsg("Media is unavailable");
        		return;
    	}
        Intent i = new Intent(this, FileDialog.class);
        startActivityForResult(i, ACTIVITY_GET_FILENAME);
    }
    
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        //result of open file dialog
        if (requestCode == ACTIVITY_GET_FILENAME && resultCode == RESULT_OK) {
        	String filename = intent.getStringExtra(KEY_FILE_NAME);
        	if (filename.length() > 0) {
        		mCurrentEntry = -1;
        		loadDatabase(filename);
        	}
        }
        //result of list first lines
        if (requestCode == ACTIVITY_DISPLAY_LIST && resultCode == RESULT_OK) {
        	int result = intent.getIntExtra(KEY_LIST_SELECTION, -1);
        	if (result > -1) {
        		showEntry(result);
        	}
        }
        //result of new entry
        if (requestCode == ACTIVITY_NEW_ENTRY && resultCode == RESULT_OK) {
        	String title = intent.getStringExtra(Keyring.KEY_ENTRY_TITLE_TEXT);
        	byte[] record = createRecord(intent);
        	if (title.length() > 0 && record.length > 0) addNewEntry(title, record);
        }
        //result of edit entry
        if (requestCode == ACTIVITY_EDIT_ENTRY && resultCode == RESULT_OK) {
        	String title = intent.getStringExtra(Keyring.KEY_ENTRY_TITLE_TEXT);
        	byte[] record = createRecord(intent);
        	if (intent.getIntExtra(Keyring.KEY_ENTRY_ID, -1) == mCurrentEntry &&
        		mCurrentEntry > -1 && title.length() > 0 && record.length > 0) {
        			editEntry(title, record);
        	}
        }
        //result of set preferences
        if (requestCode == ACTIVITY_SET_PREFERENCES) {
        	restorePreferences();
        }
    }
	

    private byte [] createRecord(Intent intent) {
    	byte[] record = null;
    	// set record format & IV length
		switch(model.pdbVersion) {
			case 4:
				record = Model.toRecordFormat4(
					intent.getStringExtra(Keyring.KEY_ENTRY_ACCOUNT_TEXT) + "\0" +
					intent.getStringExtra(Keyring.KEY_ENTRY_PASSWD_TEXT) + "\0" +
					intent.getStringExtra(Keyring.KEY_ENTRY_NOTES_TEXT) + "\0");
				break;
			case 5:
				record = Model.toRecordFormat5(
					intent.getStringExtra(Keyring.KEY_ENTRY_ACCOUNT_TEXT),
					intent.getStringExtra(Keyring.KEY_ENTRY_PASSWD_TEXT),
					intent.getStringExtra(Keyring.KEY_ENTRY_NOTES_TEXT));
				break;
		}
		return record;
    }
    
    
	private void addNewEntry(String title, byte[] record) {
		byte[] ciphertext;
		int recordLength = 0;
		int newEntryId = model.getEntriesSize() + 1;
		
		try {
			// encrypt record
			ciphertext = model.crypto.encrypt(record);

			int ivLen = (model.pdbVersion == 5 && model.crypto.type != 1) ? 16 : 8;
			int len = title.length() + ciphertext.length - 16;
			switch (model.pdbVersion) {
				case 4: recordLength = len + 1;	break;
				case 5:	recordLength = len + 4 + (len % 2) + ivLen;	break;
			}

			// get new unique id
			int id = model.getNewUniqueId();

			// new entry object
			Entry myEntry = new Entry(
				newEntryId,
				title,
				0,
				Model.sliceBytes(ciphertext, 16, ciphertext.length - 16),
				model.crypto,
				0x40,
				id,
				recordLength,
				Model.sliceBytes(ciphertext, 0, ivLen));

			// register new entry to vector entries
			model.addEntry((Object) myEntry);

			// save database
			model.saveData(mFilename);

			//rebuild list of titles
			mCurrentEntry = sortEntries(newEntryId);
			showEntry(mCurrentEntry);
		}
		catch(Exception ex) {
			msgError(ex, "Add New Entry: ", true);
		}
    }
	

	private void editEntry(String title, byte[] record) {
		try {
			// encrypt record
			byte[] ciphertext = model.crypto.encrypt(record);

			int ivLen = (model.pdbVersion == 5 && model.crypto.type != 1) ? 16 : 8;
			int len = title.length() + ciphertext.length - 16;
			int recordLength = 0;
			switch (model.pdbVersion) {
				case 4: recordLength = len + 1;	break;
				case 5:	recordLength = len + 4 + (len % 2) + ivLen;	break;
			}

			// get new unique id
			int id = model.getNewUniqueId();

	        Entry myEntry = (Entry) model.getEntries().get(mCurrentEntry);
	        if (myEntry.entryId != mTitleIdList.get(mCurrentEntry)) {
	        	alertMsg("Edit entry: bad entry id");
	        	return;
	        }
	        
			myEntry.title = title;
			myEntry.encrypted = Model.sliceBytes(ciphertext, 16, ciphertext.length - 16);
			myEntry.category = 0;
			myEntry.attribute = 0x40;
			myEntry.recordLength = recordLength;
			myEntry.iv = Model.sliceBytes(ciphertext, 0, ivLen);
	        
			// save database
			model.saveData(mFilename);

			//rebuild list of titles
			mCurrentEntry = sortEntries(myEntry.entryId);
			showEntry(mCurrentEntry);
		}
		catch(Exception ex) {
			msgError(ex, "Edit Entry: ", true);
		}
    }
	

	private void displayAbout() {
		String aboutInfo = "Keyring for Android\nversion 1.0\n" +
				"Copyright 2011 Peter Newman\n";
		aboutInfo += "www.pnewman.com/keyring\n\n";
		
		aboutInfo += (mFilename != null) ?
				"Filename: " + extractFileName(mFilename) : "No file loaded";

		if (model.getVersion() == 5) {
			aboutInfo += "\nFile format version: 5\nAlgorithm: ";
			switch(model.crypto.type) {
			case 1: aboutInfo += "Triple DES"; break;
			case 2: aboutInfo += "AES 128-bit"; break;
			case 3: aboutInfo += "AES 256-bit"; break;
			default: aboutInfo += "invalid type";
			}
		}
		else if (model.getVersion() == 4) {
			aboutInfo += "\nFile format version: 4\nAlgorithm: Triple DES";
		}
		else {
			aboutInfo += "\nFile format: invalid version id";
		}
		aboutInfo += "\nEntries: " + model.getEntriesSize() + "\n\n";

		aboutInfo +=
			"Keyring for Android is based on KeyringEditor Copyright 2004 Markus Griessnig.\n\n" +
			"KeyringEditor is based on Java Keyring v0.6 Copyright 2004 Frank Taylor.\n\n" +
			"Both are derived from Keyring for Palm OS: gnukeyring.sourceforge.net.\n\n";

		aboutInfo +=
		"This program is free software; you can redistribute it and/or modify it under " +
		"the terms of the GNU General Public License as published by the Free Software " +
		"Foundation; either version 3 of the License, or (at your option) any later version.\n\n";

		aboutInfo +=
		"This program is distributed in the hope that it will be useful, but WITHOUT ANY " +
		"WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A " +
		"PARTICULAR PURPOSE.  See the GNU General Public License for more details: " +
		"www.gnu.org/licenses/.";
			
		Intent i = new Intent(this, Help.class);
        i.putExtra(KEY_DISPLAY_HELP_FILE, aboutInfo);
        i.putExtra(KEY_DISPLAY_PAGE_TITLE, getString(R.string.about_page_title));
        startActivity(i);
	}
	
	
    private void loadHelpFile() {
    	final int BUFSIZE = 1024;

    	char buf[] = new char[BUFSIZE];
    	InputStream is = getResources().openRawResource(R.raw.helpfile);
    	InputStreamReader isr = new InputStreamReader(is);
    	StringBuilder stringBuf = new StringBuilder();
		int bytesRead = 0;
    	try {
			while (bytesRead > -1) {
    			bytesRead = isr.read(buf, 0, BUFSIZE);
		    	for (int i=0; i < bytesRead; ++i) {
		    		if (buf[i] != '\r') stringBuf.append(buf[i]);
		    	}
			}
			isr.close();
    	}
    	catch (IOException e) {
    		alertMsg("File Read Exception reading help file");
    		return;
    	}

    	String helpFile = stringBuf.toString();
    	if (helpFile.length() == 0) {
    		alertMsg("Problem reading help file");
    		return;
    	}
    	
    	Intent i = new Intent(this, Help.class);
        i.putExtra(KEY_DISPLAY_HELP_FILE, stringBuf.toString());
        i.putExtra(KEY_DISPLAY_PAGE_TITLE, getString(R.string.help_dialog_title));
        startActivity(i);
    }
 
    
	//test Password-Based Key Derivation algorithm pbkdf2
	private void testPbkdf2() {
		String passwdStr = "password";
		String saltStr = "ATHENA.MIT.EDUraeburn";
		int iter = 1200;
		int keylen = 32;
		mBodyText.setText(model.testPbkdf2(passwdStr, saltStr, iter, keylen));
	}
	
	
	public void showStatusMsgShort(String msg) {
    	Toast.makeText(Keyring.this, msg, Toast.LENGTH_SHORT).show();
    }
	

	public void showStatusMsgLong(String msg) {
    	Toast.makeText(Keyring.this, msg, Toast.LENGTH_LONG).show();
    }
	
	
    private void msgError(Exception ex, String msg, boolean ignore) {
    	alertMsg(msg + " " + ex.getMessage());
    }

    
    private void alertMsg(String msg) {
    	new AlertDialog.Builder(this)
//    		.setIcon(R.drawable.icon)
    		.setMessage(msg)
    		.setPositiveButton("OK", 
    			new DialogInterface.OnClickListener() {
    				@Override
    				public void onClick(DialogInterface dialog, int which) { }
    			}).show();
    }

}